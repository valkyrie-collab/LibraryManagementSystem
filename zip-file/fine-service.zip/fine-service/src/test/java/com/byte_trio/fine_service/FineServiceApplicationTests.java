package com.byte_trio.fine_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FineServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
