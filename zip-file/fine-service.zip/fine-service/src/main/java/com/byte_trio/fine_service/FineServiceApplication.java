package com.byte_trio.fine_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FineServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FineServiceApplication.class, args);
	}

}
